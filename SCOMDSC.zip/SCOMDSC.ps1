﻿#Configuration to Install SQL & SCOM
Configuration SCOMInstall
{
	   param 
   ( 
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Credential,
        
        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [String]$SourcePath,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$StorageCred,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$SQLDBESvcAcc,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$SQLAgtSvcAcc,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$SQLRepSvcAcc,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$SCOMActSvcAcc,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$SCOMDasSvcAcc,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$SCOMDRSvcAcc,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$SCOMDWSvcAcc,

        [Parameter(Mandatory)]
        [String]$SvcSQLDBE,
        
        [Parameter(Mandatory)]
        [String]$SvcSQLAGT
    )
    
    #Import the required DSC Resources 
    Import-DscResource -Module xComputerManagement, xSQLServer, UserRights, SQLPS, PSDesiredStateConfiguration, xSCOM
        
    #[System.Management.Automation.PSCredential]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Credential.UserName)", $Credential.Password)
    #[System.Management.Automation.PSCredential]$StorageCreds = New-Object System.Management.Automation.PSCredential ("jayav", $StorageCredential.Password)
    #[System.Management.Automation.PSCredential]$SQLDBECreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($SQLDBESvcAcc.UserName)", $SQLDBESvcAcc.Password)
    #[System.Management.Automation.PSCredential]$SQLAgtCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($SQLAgtSvcAcc.UserName)", $SQLAgtSvcAcc.Password)
    #[System.Management.Automation.PSCredential]$SQLRepCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($SQLRepSvcAcc.UserName)", $SQLRepSvcAcc.Password)

    Node localhost
    {
        LocalConfigurationManager 
        {
            ConfigurationMode = 'ApplyOnly'
            RebootNodeIfNeeded = $true
        }

        WindowsFeature NetFramework35Core
        {
            Name = "NET-Framework-Core"
            Ensure = "Present"
        }

        WindowsFeature NetFramework45Core
        {
            Name = "NET-Framework-45-Core"
            Ensure = "Present"
        }

        File SourceDownload
		{
			DestinationPath = "C:\Install"
			Ensure = "Present"
			Credential = $StorageCred
			SourcePath = $SourcePath
			Type = "Directory"
			Recurse = $true
		}
		
        Script ChangeEDrive
        {
            GetScript = 
            {
                $Drives = (Get-Volume).DriveLetter
                $result = @{ 
                    Letter = $Drives
                }
                $result
            }
            SetScript = 
            {
                Write-Verbose "Checking to see if E is in use by DVD drive"
				$EDVD = get-Volume | Where {$_.driveletter -eq 'E' -and $_.DriveType -eq 'CD-ROM'} -ErrorAction SilentlyContinue
                If($EDVD)
                {
                    Write-Verbose "E drive taken by DVD drive. Now changing to X"
                    $drive = Get-WmiObject -Class win32_volume -Filter "DriveLetter = 'E:'"
                    Set-WmiInstance -input $drive -Arguments @{DriveLetter="X:"; Label="DVD Drive"} | Out-Null
                }
               
            }
                TestScript = 
			{
				$EDVD = get-Volume | Where {$_.driveletter -eq 'E' -and $_.DriveType -eq 'CD-ROM'} -ErrorAction SilentlyContinue
				If($EDVD){
					$false
				}
				Else
				{
					$true
				}
			}

		}

		Script MountDataDisks
        {
            GetScript = 
            {
                $DataDisks = (get-disk).count
                $result = @{ 
                    Number = $DataDisks
                }
                $result
            }
            SetScript = 
            {
                $disks = get-disk | Where partitionstyle -eq 'raw'
                Foreach ($d in $disks )
                {

                    if ($d.number -eq 2)
                        {
                            write-verbose "$($d.number) is for Applications Install"
                            get-disk $($d.number) | Initialize-Disk -PartitionStyle MBR -PassThru |
                            New-Partition -AssignDriveLetter -UseMaximumSize |
                            Format-Volume -FileSystem NTFS -NewFileSystemLabel "Applications" -confirm:$false -ErrorAction Stop -Force
                            $volumelabel = ((Get-Volume -FileSystemLabel "Applications").driveletter)
                            If ($volumelabel -notlike "E")
                                {
                                    set-Partition -DriveLetter $volumelabel -NewDriveLetter E
                                }
                        }
                    
                    if ($d.number -eq 3) 
                        {
                            write-verbose "$($d.number) is for SQL Data"
                            get-disk $($d.number) | Initialize-Disk -PartitionStyle MBR -PassThru |
                            New-Partition -AssignDriveLetter -UseMaximumSize |
                            Format-Volume -FileSystem NTFS -AllocationUnitSize 65536 -NewFileSystemLabel "SQL Data" -confirm:$false -ErrorAction Stop -Force
                            $volumelabel = ((Get-Volume -FileSystemLabel "SQL Data").driveletter)
                            If ($volumelabel -notlike "F")
                                {
                                    set-Partition -DriveLetter $volumelabel -NewDriveLetter F
                                }
                        }
                    
                    if ($d.number -eq 4)
                        {
                            write-verbose "$($d.number) is for SQL Logs"
                            get-disk $($d.number) | Initialize-Disk -PartitionStyle MBR -PassThru |
                            New-Partition -AssignDriveLetter -UseMaximumSize |
                            Format-Volume -FileSystem NTFS -AllocationUnitSize 65536 -NewFileSystemLabel "SQL Logs" -confirm:$false -ErrorAction Stop -Force
                            $volumelabel = ((Get-Volume -FileSystemLabel "SQL Logs").driveletter)
                            If ($volumelabel -notlike "G")
                                {
                                    set-Partition -DriveLetter $volumelabel -NewDriveLetter G
                                }
                        }
                    
                    if ($d.number -eq 5)
                        {
                            write-verbose "$($d.number) is for Backups"
                            get-disk $($d.number) | Initialize-Disk -PartitionStyle MBR -PassThru |
                            New-Partition -AssignDriveLetter -UseMaximumSize |
                            Format-Volume -FileSystem NTFS -NewFileSystemLabel "Backups" -confirm:$false -ErrorAction Stop -Force
                            $volumelabel = ((Get-Volume -FileSystemLabel "Backups").driveletter)
                            If ($volumelabel -notlike "H")
                            {
                                set-Partition -DriveLetter $volumelabel -NewDriveLetter H
                            }
                        }
                    if ($d.number -eq 6)
                        {
                            write-verbose "$($d.number) is for SCCM Content"
                            get-disk $($d.number) | Initialize-Disk -PartitionStyle MBR -PassThru |
                            New-Partition -AssignDriveLetter -UseMaximumSize |
                            Format-Volume -FileSystem NTFS -NewFileSystemLabel "SCCM Content" -confirm:$false -ErrorAction Stop -Force
                            $volumelabel = ((Get-Volume -FileSystemLabel "SCCM Content").driveletter)
                            If ($volumelabel -notlike "I")
                            {
                                set-Partition -DriveLetter $volumelabel -NewDriveLetter I
                            }
                        }

                }#End foreach
            }#End SetScript

                TestScript =
                {
                    $rawdisks = get-disk | Where partitionstyle -eq 'raw'
                    if ($rawdisks.count -eq 0) {
						$test = $true
                        Write-Verbose "$env:COMPUTERNAME - All disks have been initialised"
                        } else {
						$test = $false
                        Write-Verbose "$env:COMPUTERNAME - still has raw disks"
                        }
                    $test
                }
			DependsOn = "[Script]ChangeEDrive"
        }#End of Add Disk Script
		
        File TempDB {
            Type = 'Directory'
            DestinationPath = 'D:\TempDB'
            Ensure = "Present"
        }

        File SQLData {
            Type = 'Directory'
            DestinationPath = 'F:\Data'
            Ensure = "Present"
        }

        File SQLLogs {
            Type = 'Directory'
            DestinationPath = 'G:\Logs'
            Ensure = "Present"
        }

        File SQLBackups {
            Type = 'Directory'
            DestinationPath = 'H:\Backups'
            Ensure = "Present"
        }

        File SQLInstallDirectory {
            Type = 'Directory'
            DestinationPath = 'E:\Program Files\Microsoft SQL Server'
            Ensure = "Present"
        }

        File SQLInstallDirectoryWOW {
            Type = 'Directory'
            DestinationPath = 'E:\Program Files (x86)\Microsoft SQL Server'
            Ensure = "Present"
        }

        WindowsFeature ADPowerShell 
        {
            Ensure = "Present"
            Name = "RSAT-AD-PowerShell"
            
        }

        xSqlServerSetup SQLInstall
        {
            SourcePath = "C:\Install\SQL2014"
            SetupCredential = $Credential
            InstanceName = "SCOM"
            Features = "SQLENGINE,FULLTEXT,AS,RS,SSMS,ADV_SSMS"
            SQLCollation = "SQL_Latin1_General_CP1_CI_AS"
            SQLSysAdminAccounts = "SKYNET\SQL Admins"
            SQLSvcAccount = $SQLDBESvcAcc
            AgtSvcAccount = $SQLAgtSvcAcc
            RSSvcAccount = $SQLRepSvcAcc
            InstallSharedDir = "E:\Program Files\Microsoft SQL Server"
            InstallSharedWOWDir = "E:\Program Files (x86)\Microsoft SQL Server"
            InstanceDir = "E:\Program Files\Microsoft SQL Server"
            InstallSQLDataDir = "E:\Program Files\Microsoft SQL Server"
            SQLUserDBDir = "F:\Data"
            SQLUserDBLogDir = "G:\Logs"
            SQLTempDBDir = "D:\TempDB"
            SQLTempDBLogDir = "D:\TempDB"
            SQLBackupDir = "H:\Backups"
        }
         
        xSQLServerNetwork SetSQLPort
        {
            DependsOn = "[xSqlServerSetup]SQLInstall"
            InstanceName = "SCOM"
            ProtocolName = "tcp"
            IsEnabled = $true
            TCPPort = 1433
            RestartService = $true 
        }

        #xSQLServerMemory SetSQLMemory
        #{
        #    DynamicAlloc = 0
        #    MinMemory = $MinMem
        #    MaxMemory = $MaxMem
        #    #SQLServer = $Node
        #    SQLInstanceName = $node.instance
        #}

        Script SetLockMemeoryPriv
        {
            GetScript = {
                $acc = $using:SvcSQLDBE
                $result = Get-UserRightsGrantedToAccount $acc
                $result
            }
    
            SetScript = {
                $acc = $using:SvcSQLDBE
                Grant-UserRight -Account $acc -Right SeLockMemoryPrivilege, SeManageVolumePrivilege
            
            }
    
            TestScript = {
                $acc = $using:SvcSQLDBE
                $svcacc = Get-UserRightsGrantedToAccount $acc
                if ($svcacc.Right -contains "SeLockMemoryPrivilege") {
	            $test = $true
                Write-Verbose "$svcacc - already has the Lock Memory Privilege - SKIPPING"
                } 
                else {
	            $test = $false
                Write-Verbose "$svcacc - does not have the Lock Memory Privilege - APPLYING"
            }
            
            $test
            
            }

        }

        Script SetManageVolumePrivilegeSQLDBE
        {
            GetScript = {
                $acc = $using:SvcSQLDBE
                $result = Get-UserRightsGrantedToAccount $acc
                $result
            }
    
            SetScript = {
                $acc = $using:SvcSQLDBE
                Grant-UserRight -Account $acc -Right SeManageVolumePrivilege
            
            }
    
            TestScript = {
                $acc = $using:SvcSQLDBE
                $svcacc = Get-UserRightsGrantedToAccount $acc
                if ($svcacc.Right -contains "SeManageVolumePrivilege") {
	            $test = $true
                Write-Verbose "$svcacc - already has the Lock Memory Privilege - SKIPPING"
                } 
                else {
	            $test = $false
                Write-Verbose "$svcacc - does not have the Lock Memory Privilege - APPLYING"
            }
            
            $test
            
            }

        }

        Script SetManageVolumePrivilegeSQLAgt
        {
            GetScript = {
                $acc = $using:SvcSQLAGT
                $result = Get-UserRightsGrantedToAccount $acc
                $result
            }
    
            SetScript = {
                $acc = $using:SvcSQLAGT
                Grant-UserRight -Account $acc -Right SeManageVolumePrivilege
            
            }
    
            TestScript = {
                $acc = $using:SvcSQLAGT
                $svcacc = Get-UserRightsGrantedToAccount $acc
                if ($svcacc.Right -contains "SeManageVolumePrivilege") {
	            $test = $true
                Write-Verbose "$svcacc - already has the Lock Memory Privilege - SKIPPING"
                } 
                else {
	            $test = $false
                Write-Verbose "$svcacc - does not have the Lock Memory Privilege - APPLYING"
            }
            
            $test
            
            }

        }

        Script SQLConfig
        {
            GetScript = {

                #Name of the SQL Server Instance
                $InstanceName = "SCOM"
                #if ($InstanceName -eq "MSSQLSERVER") {$InstanceName = "Default"}
               
                #Path to the Instance
                $InstanceName = "SQLSERVER:\SQL\localhost\$InstanceName" 

            }
    
            SetScript = {
                   
$SQLQuery = @"

/* This shows the advanced options */
EXEC sys.sp_configure N'show advanced options', N'1'  RECONFIGURE WITH OVERRIDE
GO

/* Find the optimal max degree of parallelism setting */
BEGIN
DECLARE @MAXDOP int;
SET @MAXDOP = 
(
	SELECT CASE WHEN cpu_count / hyperthread_ratio > 8 THEN 8 ELSE cpu_count / hyperthread_ratio END AS optimal_maxdop FROM sys.dm_os_sys_info
)
EXEC sys.sp_configure N'max degree of parallelism', @MAXDOP  RECONFIGURE WITH OVERRIDE;
END
GO

/* Change the size and growth parameters of TempDB */
USE [master]
GO
ALTER DATABASE [tempdb] MODIFY FILE ( NAME = N'tempdev', SIZE = 8388608KB , FILEGROWTH = 512000KB )
GO
ALTER DATABASE [tempdb] MODIFY FILE ( NAME = N'templog', SIZE = 2097152KB , FILEGROWTH = 102400KB )
GO

/* Hide the advanced options */
EXEC sys.sp_configure N'show advanced options', N'0'  RECONFIGURE WITH OVERRIDE
GO

"@
                #Name of the SQL Server Instance
                $InstanceName = "SCOM"
                #if ($InstanceName -eq "MSSQLSERVER") {$InstanceName = "Default"}
               
                #Path to the Instance
                $InstanceName = "SQLSERVER:\SQL\$env:COMPUTERNAME\$InstanceName"
                Write-Verbose "$InstanceName"
                #Change to the SQL Server Location
                Import-Module SQLPS
                Set-Location $InstanceName
                #Run the SQL statement
                Invoke-Sqlcmd -ServerInstance (Get-Item .) -Query $SQLQuery
            
            }
    
            TestScript = {
                $TempDB = Get-Item -Path d:\TempDB\tempdb.mdf
                if ($TempDB.Length -eq 8GB) {
                $test = $true
                Write-Verbose "SQL Post-Install Configuration Script already run"
                }
                else {
                $test = $false
                Write-Verbose "Running SQL Post-Install Configuration Script"
                }
                $test
            }

        }

        WindowsFeature "Web-WebServer"
        {
            Ensure = "Present"
            Name = "Web-WebServer"
        }

        WindowsFeature "Web-Request-Monitor"
        {
            Ensure = "Present"
            Name = "Web-Request-Monitor"
        }

        WindowsFeature "Web-Windows-Auth"
        {
            Ensure = "Present"
            Name = "Web-Windows-Auth"
        }

        WindowsFeature "Web-Asp-Net"
        {
            Ensure = "Present"
            Name = "Web-Asp-Net"
        }

        WindowsFeature "Web-Asp-Net45"
        {
            Ensure = "Present"
            Name = "Web-Asp-Net45"
        }

        WindowsFeature "NET-WCF-HTTP-Activation45"
        {
            Ensure = "Present"
            Name = "NET-WCF-HTTP-Activation45"
        }

        WindowsFeature "Web-Mgmt-Console"
        {
            Ensure = "Present"
            Name = "Web-Mgmt-Console"
        }

        WindowsFeature "Web-Metabase"
        {
            Ensure = "Present"
            Name = "Web-Metabase"
        }

        Package "SQLServer2012SystemCLRTypes"
        {
            Ensure = "Present"
            Name = "Microsoft System CLR Types for SQL Server 2012 (x64)"
            ProductId = ""
            Path = "C:\Install\SCOM2012\PreReqs\SQLSysClrTypes.msi"
            Arguments = "ALLUSERS=2"
            Credential = $Credential
        }
        
        Package "ReportViewer2012Redistributable"
        {
            DependsOn = "[Package]SQLServer2012SystemCLRTypes"
            Ensure = "Present"
            Name = "Microsoft Report Viewer 2012 Runtime"
            ProductId = ""
            Path = "C:\Install\SCOM2012\PreReqs\ReportViewer.msi"
            Arguments = "ALLUSERS=2"
            Credential = $Credential
        }

        Group "Administrators"
        {
            GroupName = "Administrators"
            MembersToInclude = @(
                $act.UserName,
                $das.UserName
            )
            Credential = $Credential
        }

        xSCOMManagementServerSetup "OMMS"
        {
            DependsOn = "[Group]Administrators"
            Ensure = "Present"
            SourcePath = "C:\Install\SCOM2012"
            SetupCredential = $Credential
            ProductKey = "BXH69-M62YX-QQD6R-3GPWX-8WMFY"
            ManagementGroupName = "OM_Contoso"
            FirstManagementServer = $true
            ActionAccount = $SCOMActSvcAcc
            DASAccount = $SCOMDasSvcAcc
            DataReader = $SCOMDRSvcAcc
            DataWriter = $SCOMDWSvcAcc
            SqlServerInstance = "localhost\SCOM"
            DwSqlServerInstance = "localhost\SCOM"
        }

        xSCOMReportingServerSetup "OMRS"
        {
            DependsOn = "[xSCOMManagementServerSetup]OMMS"
            Ensure = "Present"
            SourcePath = "C:\Install\SCOM2012"
            SetupCredential = $Credential
            ManagementServer = "localhost"
            SRSInstance = "localhost\SCOM"
            DataReader = $SCOMDRSvcAcc
        }

        xSCOMWebConsoleServerSetup "OMWC"
        {
            DependsOn = "[xSCOMReportingServerSetup]OMRS"
            Ensure = "Present"
            SourcePath = "C:\Install\SCOM2012"
            SetupCredential = $Credential
            ManagementServer = "localhost"
        }

        xSCOMConsoleSetup "OMC"
        {
            DependsOn = @(
                "[Package]SQLServer2012SystemCLRTypes",
                "[Package]ReportViewer2012Redistributable",
                "[xSCOMManagementServerSetup]OMMS"
            )
            Ensure = "Present"
            SourcePath = "C:\Install\SCOM2012"
            SetupCredential = $Credential
        }   
    }
}  