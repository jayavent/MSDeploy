﻿#Configuration to Install SQL & SCOM
Configuration SCOMInstall
{
	   param 
   ( 
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Credential,
        
        [Parameter(Mandatory=$true)]
        [String]$Sourcepath,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$StorageCredential

    )
    
    #Import the required DSC Resources 
    Import-DscResource -Module xComputerManagement, xSQLServer, UserRights, SQLPS, PSDesiredStateConfiguration, xSCOM
        
    Node $env:COMPUTERNAME
    { 
        
        WindowsFeature NetFramework35Core
        {
            Name = "NET-Framework-Core"
            Ensure = "Present"
        }
 
        WindowsFeature NetFramework45Core
        {
            Name = "NET-Framework-45-Core"
            Ensure = "Present"
        }

        File SourceDownload
		{
			DestinationPath = "C:\Install"
			Ensure = "Present"
			Credential = $StorageCreds
			SourcePath = "$sourcepath"
			Type = "Directory"
			Recurse = $true
		}
        
    }

    LocalConfigurationManager 
    {
        ConfigurationMode = 'ApplyOnly'
        RebootNodeIfNeeded = $true
    }
}  