﻿#Configuration to Install SQL & SCOM
Configuration SCOMInstall
{
	   param 
   ( 
        [Parameter(Mandatory=$true)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Credential,
        
        [Parameter(Mandatory)]
        [String]$Sourcepath,

        [Parameter(Mandatory)]
        [PSCredential] $StorageCred

    )
    
    #Import the required DSC Resources 
    Import-DscResource -Module xComputerManagement, xSQLServer, UserRights, SQLPS, PSDesiredStateConfiguration, xSCOM

    #[System.Management.Automation.PSCredential]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Credential.UserName)", $Credential.Password)
    #[System.Management.Automation.PSCredential] $StorageCreds = New-Object System.Management.Automation.PSCredential ($StorageCred.UserName, $StorageCred.Password)
        
    Node $env:COMPUTERNAME
    { 
        LocalConfigurationManager 
        {
            ActionAfterReboot = 'ContinueConfiguration'
            ConfigurationMode = 'ApplyOnly'
            RebootNodeIfNeeded = $true
        }

        WindowsFeature NetFramework35Core
        {
            Name = "NET-Framework-Core"
            Ensure = "Present"
        }
 
        WindowsFeature NetFramework45Core
        {
            Name = "NET-Framework-45-Core"
            Ensure = "Present"
        }

        File SourceDownload
		{
			DestinationPath = "C:\Install"
			Ensure = "Present"
			Credential = $StorageCred
			SourcePath = $Sourcepath
			Type = "Directory"
			Recurse = $true
		}
    }
}  