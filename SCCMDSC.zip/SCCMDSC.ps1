﻿#Configuration to Join Domain and Install SQl
Configuration SCCMInstall
{
	   param 
   ( 
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Credential,
        
        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [String]$Sourcepath,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$StorageCredential,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$SQLDBESvcAcc,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$SQLAgtSvcAcc,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$SQLRepSvcAcc
    )
    
    #Import the required DSC Resources 
    Import-DscResource -Module xComputerManagement, xSQLServer 
        
    [System.Management.Automation.PSCredential ]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Credential.UserName)", $Credential.Password)
    [System.Management.Automation.PSCredential ]$StorageCreds = New-Object System.Management.Automation.PSCredential ("jayav", $StorageCredential.Password)
    [System.Management.Automation.PSCredential ]$SQLDBECreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($SQLDBESvcAcc.UserName)", $SQLDBESvcAcc.Password)
    [System.Management.Automation.PSCredential ]$SQLAgtCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($SQLAgtSvcAcc.UserName)", $SQLAgtSvcAcc.Password)
    [System.Management.Automation.PSCredential ]$SQLRepCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($SQLRepSvcAcc.UserName)", $SQLRepSvcAcc.Password)

    Node localhost
    { 

        xComputer JoinDomain 
        { 
			Name = $env:computername
            DomainName    = $DomainName
            Credential    = $DomainCreds  # Credential to join to domain 
        }
        
        WindowsFeature NetFramework35Core
        {
            Name = "NET-Framework-Core"
            Ensure = "Present"
        }
 
        WindowsFeature NetFramework45Core
        {
            Name = "NET-Framework-45-Core"
            Ensure = "Present"
        }

        File SQLBinaryDownload
		{
			DestinationPath = "C:\Install"
			Ensure = "Present"
			Credential = $StorageCreds
			SourcePath = "$sourcepath"
			Type = "Directory"
			Recurse = $true
		}
		
        Script ChangeEDrive
        {
            GetScript = 
            {
                $Drives = (Get-Volume).DriveLetter
                $result = @{ 
                    Letter = $Drives
                }
                $result
            }
            SetScript = 
            {
                Write-Verbose "Checking to see if E is in use by DVD drive"
				$EDVD = get-Volume | Where {$_.driveletter -eq 'E' -and $_.DriveType -eq 'CD-ROM'} -ErrorAction SilentlyContinue
                If($EDVD)
                {
                    Write-Verbose "E drive taken by DVD drive. Now changing to X"
                    $drive = Get-WmiObject -Class win32_volume -Filter "DriveLetter = 'E:'"
                    Set-WmiInstance -input $drive -Arguments @{DriveLetter="X:"; Label="DVD Drive"} | Out-Null
                }
               
            }
                TestScript = 
			{
				$EDVD = get-Volume | Where {$_.driveletter -eq 'E' -and $_.DriveType -eq 'CD-ROM'} -ErrorAction SilentlyContinue
				If($EDVD){
					$false
				}
				Else
				{
					$true
				}
			}

		}

		Script MountDataDisks
        {
            GetScript = 
            {
                $DataDisks = (get-disk).count
                $result = @{ 
                    Number = $DataDisks
                }
                $result
            }
            SetScript = 
            {
                $disks = get-disk | Where partitionstyle -eq 'raw'
                Foreach ($d in $disks )
                {

                    if ($d.number -eq 2)
                        {
                            write-verbose "$($d.number) is for Applications Install"
                            get-disk $($d.number) | Initialize-Disk -PartitionStyle MBR -PassThru |
                            New-Partition -AssignDriveLetter -UseMaximumSize |
                            Format-Volume -FileSystem NTFS -NewFileSystemLabel "Applications" -confirm:$false -ErrorAction Stop -Force
                            $volumelabel = ((Get-Volume -FileSystemLabel "Applications").driveletter)
                            If ($volumelabel -notlike "E")
                                {
                                    set-Partition -DriveLetter $volumelabel -NewDriveLetter E
                                }
                        }
                    
                    if ($d.number -eq 3) 
                        {
                            write-verbose "$($d.number) is for SQL Data"
                            get-disk $($d.number) | Initialize-Disk -PartitionStyle MBR -PassThru |
                            New-Partition -AssignDriveLetter -UseMaximumSize |
                            Format-Volume -FileSystem NTFS -AllocationUnitSize 65536 -NewFileSystemLabel "SQL Data" -confirm:$false -ErrorAction Stop -Force
                            $volumelabel = ((Get-Volume -FileSystemLabel "SQL Data").driveletter)
                            If ($volumelabel -notlike "F")
                                {
                                    set-Partition -DriveLetter $volumelabel -NewDriveLetter F
                                }
                        }
                    
                    if ($d.number -eq 4)
                        {
                            write-verbose "$($d.number) is for SQL Logs"
                            get-disk $($d.number) | Initialize-Disk -PartitionStyle MBR -PassThru |
                            New-Partition -AssignDriveLetter -UseMaximumSize |
                            Format-Volume -FileSystem NTFS -AllocationUnitSize 65536 -NewFileSystemLabel "SQL Logs" -confirm:$false -ErrorAction Stop -Force
                            $volumelabel = ((Get-Volume -FileSystemLabel "SQL Logs").driveletter)
                            If ($volumelabel -notlike "G")
                                {
                                    set-Partition -DriveLetter $volumelabel -NewDriveLetter G
                                }
                        }
                    
                    if ($d.number -eq 5)
                        {
                            write-verbose "$($d.number) is for Backups"
                            get-disk $($d.number) | Initialize-Disk -PartitionStyle MBR -PassThru |
                            New-Partition -AssignDriveLetter -UseMaximumSize |
                            Format-Volume -FileSystem NTFS -NewFileSystemLabel "Backups" -confirm:$false -ErrorAction Stop -Force
                            $volumelabel = ((Get-Volume -FileSystemLabel "Backups").driveletter)
                            If ($volumelabel -notlike "H")
                            {
                                set-Partition -DriveLetter $volumelabel -NewDriveLetter H
                            }
                        }
                    if ($d.number -eq 6)
                        {
                            write-verbose "$($d.number) is for SCCM Content"
                            get-disk $($d.number) | Initialize-Disk -PartitionStyle MBR -PassThru |
                            New-Partition -AssignDriveLetter -UseMaximumSize |
                            Format-Volume -FileSystem NTFS -NewFileSystemLabel "SCCM Content" -confirm:$false -ErrorAction Stop -Force
                            $volumelabel = ((Get-Volume -FileSystemLabel "SCCM Content").driveletter)
                            If ($volumelabel -notlike "I")
                            {
                                set-Partition -DriveLetter $volumelabel -NewDriveLetter I
                            }
                        }

                }#End foreach
            }#End SetScript

                TestScript =
                {
                    $rawdisks = get-disk | Where partitionstyle -eq 'raw'
                    if ($rawdisks.count -eq 0) {
						$test = $true
                        Write-Verbose "$env:COMPUTERNAME - All disks have been initialised"
                        } else {
						$test = $false
                        Write-Verbose "$env:COMPUTERNAME - still has raw disks"
                        }
                    $test
                }
			DependsOn = "[Script]ChangeEDrive"
        }#End of Add Disk Script
		
        File TempDB {
            Type = 'Directory'
            DestinationPath = 'D:\TempDB'
            Ensure = "Present"
        }

        File SQLData {
            Type = 'Directory'
            DestinationPath = 'F:\Data'
            Ensure = "Present"
        }

        File SQLLogs {
            Type = 'Directory'
            DestinationPath = 'G:\Logs'
            Ensure = "Present"
        }

        File SQLBackups {
            Type = 'Directory'
            DestinationPath = 'H:\Backups'
            Ensure = "Present"
        }

        File SQLInstallDirectory {
            Type = 'Directory'
            DestinationPath = 'E:\Program Files\Microsoft SQL Server'
            Ensure = "Present"
        }

        File SQLInstallDirectoryWOW {
            Type = 'Directory'
            DestinationPath = 'E:\Program Files (x86)\Microsoft SQL Server'
            Ensure = "Present"
        }

        xSqlServerSetup InstallSQL
        {
            SourcePath = "C:\Install\SQL2014"
            SetupCredential = $DomainCreds
            InstanceName = "SCCM"
            Features = "SQLENGINE,RS,SSMS,ADV_SSMS"
            SQLCollation = "SQL_Latin1_General_CP1_CI_AS"
            #SQLSysAdminAccounts = ""
            SQLSvcAccount = $SQLDBECreds
            AgtSvcAccount = $SQLAgtCreds
            RSSvcAccount = $SQLRepCreds
            InstallSharedDir = "E:\Program Files\Microsoft SQL Server"
            InstallSharedWOWDir = "E:\Program Files (x86)\Microsoft SQL Server"
            InstanceDir = "E:\Program Files\Microsoft SQL Server"
            InstallSQLDataDir = "E:\Program Files\Microsoft SQL Server"
            SQLUserDBDir = "F:\Data"
            SQLUserDBLogDir = "G:\Logs"
            SQLTempDBDir = "D:\TempDB"
            SQLTempDBLogDir = "D:\TempDB"
            SQLBackupDir = "H:\Backups"
        }

        Script SetLockMemeoryPriv
        {
            GetScript = {

                $result = Get-UserRightsGrantedToAccount $SQLDBECreds.UserName
                $result
    
            }
    
            SetScript = {
    
                Grant-UserRight -Account $SQLDBECreds.UserName -Right SeLockMemoryPrivilege
    
            }
    
            TestScript = {
                $svcacc = Get-UserRightsGrantedToAccount $SQLDBECreds.UserName
                if ($svcacc.Right -eq "SeLockMemoryPrivilege") {
	            $test = $false
                Write-Verbose "$svcacc - has the right"
                } 
                else {
	            $test = $true
                 Write-Verbose "$svcacc - does not"
                }
                $test
            }

        }

        LocalConfigurationManager 
        {
            ConfigurationMode = 'ApplyOnly'
            RebootNodeIfNeeded = $true
        }
    }  
}