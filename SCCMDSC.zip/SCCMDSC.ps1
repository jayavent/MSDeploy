﻿Configuration SCCMInstall
{
	   param 
   ( 
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Credential,
        
        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [String]$Sourcepath,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$StorageCredential,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$SQLDBESvcAcc,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$SQLAgtSvcAcc,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$SQLRepSvcAcc,

        [Parameter(Mandatory)]
        [String]$SvcSQLDBE,
        
        [Parameter(Mandatory)]
        [String]$SvcSQLAGT
    )
    
    #Import the required DSC Resources 
    Import-DscResource -Module xComputerManagement, xSQLServer, SQLPS, UserRights, PSDesiredStateConfiguration
        
    [System.Management.Automation.PSCredential]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Credential.UserName)", $Credential.Password)
    [System.Management.Automation.PSCredential]$StorageCreds = New-Object System.Management.Automation.PSCredential ("jayav", $StorageCredential.Password)
    [System.Management.Automation.PSCredential]$SQLDBECreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($SQLDBESvcAcc.UserName)", $SQLDBESvcAcc.Password)
    [System.Management.Automation.PSCredential]$SQLAgtCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($SQLAgtSvcAcc.UserName)", $SQLAgtSvcAcc.Password)
    [System.Management.Automation.PSCredential]$SQLRepCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($SQLRepSvcAcc.UserName)", $SQLRepSvcAcc.Password)

    Node localhost
    { 
        
        WindowsFeature NetFramework35Core
        {
            Name = "NET-Framework-Core"
            Ensure = "Present"
        }
 
        WindowsFeature NetFramework45Core
        {
            Name = "NET-Framework-45-Core"
            Ensure = "Present"
        }

        File SQLBinaryDownload
		{
			DestinationPath = "C:\Install"
			Ensure = "Present"
			Credential = $StorageCreds
			SourcePath = "$sourcepath"
			Type = "Directory"
			Recurse = $true
		}
		
        Script ChangeEDrive
        {
            GetScript = 
            {
                $Drives = (Get-Volume).DriveLetter
                $result = @{ 
                    Letter = $Drives
                }
                $result
            }
            SetScript = 
            {
                Write-Verbose "Checking to see if E is in use by DVD drive"
				$EDVD = get-Volume | Where {$_.driveletter -eq 'E' -and $_.DriveType -eq 'CD-ROM'} -ErrorAction SilentlyContinue
                If($EDVD)
                {
                    Write-Verbose "E drive taken by DVD drive. Now changing to X"
                    $drive = Get-WmiObject -Class win32_volume -Filter "DriveLetter = 'E:'"
                    Set-WmiInstance -input $drive -Arguments @{DriveLetter="X:"; Label="DVD Drive"} | Out-Null
                }
               
            }
                TestScript = 
			{
				$EDVD = get-Volume | Where {$_.driveletter -eq 'E' -and $_.DriveType -eq 'CD-ROM'} -ErrorAction SilentlyContinue
				If($EDVD){
					$false
				}
				Else
				{
					$true
				}
			}

		}

		Script MountDataDisks
        {
            GetScript = 
            {
                $DataDisks = (get-disk).count
                $result = @{ 
                    Number = $DataDisks
                }
                $result
            }
            SetScript = 
            {
                $disks = get-disk | Where partitionstyle -eq 'raw'
                Foreach ($d in $disks )
                {

                    if ($d.number -eq 2)
                        {
                            write-verbose "$($d.number) is for Applications Install"
                            get-disk $($d.number) | Initialize-Disk -PartitionStyle MBR -PassThru |
                            New-Partition -AssignDriveLetter -UseMaximumSize |
                            Format-Volume -FileSystem NTFS -NewFileSystemLabel "Applications" -confirm:$false -ErrorAction Stop -Force
                            $volumelabel = ((Get-Volume -FileSystemLabel "Applications").driveletter)
                            If ($volumelabel -notlike "E")
                                {
                                    set-Partition -DriveLetter $volumelabel -NewDriveLetter E
                                }
                        }
                    
                    if ($d.number -eq 3) 
                        {
                            write-verbose "$($d.number) is for SQL Data"
                            get-disk $($d.number) | Initialize-Disk -PartitionStyle MBR -PassThru |
                            New-Partition -AssignDriveLetter -UseMaximumSize |
                            Format-Volume -FileSystem NTFS -AllocationUnitSize 65536 -NewFileSystemLabel "SQL Data" -confirm:$false -ErrorAction Stop -Force
                            $volumelabel = ((Get-Volume -FileSystemLabel "SQL Data").driveletter)
                            If ($volumelabel -notlike "F")
                                {
                                    set-Partition -DriveLetter $volumelabel -NewDriveLetter F
                                }
                        }
                    
                    if ($d.number -eq 4)
                        {
                            write-verbose "$($d.number) is for SQL Logs"
                            get-disk $($d.number) | Initialize-Disk -PartitionStyle MBR -PassThru |
                            New-Partition -AssignDriveLetter -UseMaximumSize |
                            Format-Volume -FileSystem NTFS -AllocationUnitSize 65536 -NewFileSystemLabel "SQL Logs" -confirm:$false -ErrorAction Stop -Force
                            $volumelabel = ((Get-Volume -FileSystemLabel "SQL Logs").driveletter)
                            If ($volumelabel -notlike "G")
                                {
                                    set-Partition -DriveLetter $volumelabel -NewDriveLetter G
                                }
                        }
                    
                    if ($d.number -eq 5)
                        {
                            write-verbose "$($d.number) is for Backups"
                            get-disk $($d.number) | Initialize-Disk -PartitionStyle MBR -PassThru |
                            New-Partition -AssignDriveLetter -UseMaximumSize |
                            Format-Volume -FileSystem NTFS -NewFileSystemLabel "Backups" -confirm:$false -ErrorAction Stop -Force
                            $volumelabel = ((Get-Volume -FileSystemLabel "Backups").driveletter)
                            If ($volumelabel -notlike "H")
                            {
                                set-Partition -DriveLetter $volumelabel -NewDriveLetter H
                            }
                        }
                    if ($d.number -eq 6)
                        {
                            write-verbose "$($d.number) is for SCCM Content"
                            get-disk $($d.number) | Initialize-Disk -PartitionStyle MBR -PassThru |
                            New-Partition -AssignDriveLetter -UseMaximumSize |
                            Format-Volume -FileSystem NTFS -NewFileSystemLabel "SCCM Content" -confirm:$false -ErrorAction Stop -Force
                            $volumelabel = ((Get-Volume -FileSystemLabel "SCCM Content").driveletter)
                            If ($volumelabel -notlike "I")
                            {
                                set-Partition -DriveLetter $volumelabel -NewDriveLetter I
                            }
                        }

                }#End foreach
            }#End SetScript

                TestScript =
                {
                    $rawdisks = get-disk | Where partitionstyle -eq 'raw'
                    if ($rawdisks.count -eq 0) {
						$test = $true
                        Write-Verbose "$env:COMPUTERNAME - All disks have been initialised"
                        } else {
						$test = $false
                        Write-Verbose "$env:COMPUTERNAME - still has raw disks"
                        }
                    $test
                }
			DependsOn = "[Script]ChangeEDrive"
        }#End of Add Disk Script
		
        File TempDB {
            Type = 'Directory'
            DestinationPath = 'D:\TempDB'
            Ensure = "Present"
        }

        File SQLData {
            Type = 'Directory'
            DestinationPath = 'F:\Data'
            Ensure = "Present"
        }

        File SQLLogs {
            Type = 'Directory'
            DestinationPath = 'G:\Logs'
            Ensure = "Present"
        }

        File SQLBackups {
            Type = 'Directory'
            DestinationPath = 'H:\Backups'
            Ensure = "Present"
        }

        File SQLInstallDirectory {
            Type = 'Directory'
            DestinationPath = 'E:\Program Files\Microsoft SQL Server'
            Ensure = "Present"
        }

        File SQLInstallDirectoryWOW {
            Type = 'Directory'
            DestinationPath = 'E:\Program Files (x86)\Microsoft SQL Server'
            Ensure = "Present"
        }

        WindowsFeature ADPowerShell 
        {
            Ensure = "Present"
            Name = "RSAT-AD-PowerShell"
            
        }

        xSqlServerSetup SQLInstall
        {
            SourcePath = "C:\Install\SQL2014"
            SetupCredential = $credential
            InstanceName = "SCCM"
            Features = "SQLENGINE,RS,SSMS,ADV_SSMS"
            SQLCollation = "SQL_Latin1_General_CP1_CI_AS"
            SQLSysAdminAccounts = "SKYNET\SQL Admins"
            SQLSvcAccount = $SQLDBESvcAcc
            AgtSvcAccount = $SQLAgtSvcAcc
            RSSvcAccount = $SQLRepSvcAcc
            InstallSharedDir = "E:\Program Files\Microsoft SQL Server"
            InstallSharedWOWDir = "E:\Program Files (x86)\Microsoft SQL Server"
            InstanceDir = "E:\Program Files\Microsoft SQL Server"
            InstallSQLDataDir = "E:\Program Files\Microsoft SQL Server"
            SQLUserDBDir = "F:\Data"
            SQLUserDBLogDir = "G:\Logs"
            SQLTempDBDir = "D:\TempDB"
            SQLTempDBLogDir = "D:\TempDB"
            SQLBackupDir = "H:\Backups"
        }
         
        xSQLServerNetwork SetSQLPort
        {
            DependsOn = "[xSqlServerSetup]SQLInstall"
            InstanceName = "SCCM"
            ProtocolName = "tcp"
            IsEnabled = $true
            TCPPort = 1433
            RestartService = $true 
        }

        #xSQLServerMemory SetSQLMemory
        #{
        #    DynamicAlloc = 0
        #    MinMemory = $MinMem
        #    MaxMemory = $MaxMem
        #    #SQLServer = $Node
        #    SQLInstanceName = $node.instance
        #}

        Script SetLockMemeoryPriv
        {
            GetScript = {
                $acc = $using:SvcSQLDBE
                $result = Get-UserRightsGrantedToAccount $acc
                $result
            }
    
            SetScript = {
                $acc = $using:SvcSQLDBE
                Grant-UserRight -Account $acc -Right SeLockMemoryPrivilege, SeManageVolumePrivilege
            
            }
    
            TestScript = {
                $acc = $using:SvcSQLDBE
                $svcacc = Get-UserRightsGrantedToAccount $acc
                if ($svcacc.Right -contains "SeLockMemoryPrivilege") {
	            $test = $true
                Write-Verbose "$acc - already has the Lock Memory Privilege - SKIPPING"
                } 
                else {
	            $test = $false
                Write-Verbose "$acc - does not have the Lock Memory Privilege - APPLYING"
            }
            
            $test
            
            }

        }

        Script SetManageVolumePrivilegeSQLDBE
        {
            GetScript = {
                $acc = $using:SvcSQLDBE
                $result = Get-UserRightsGrantedToAccount $acc
                $result
            }
    
            SetScript = {
                $acc = $using:SvcSQLDBE
                Grant-UserRight -Account $acc -Right SeManageVolumePrivilege
            
            }
    
            TestScript = {
                $acc = $using:SvcSQLDBE
                $svcacc = Get-UserRightsGrantedToAccount $acc
                if ($svcacc.Right -contains "SeManageVolumePrivilege") {
	            $test = $true
                Write-Verbose "$acc - already has the Lock Memory Privilege - SKIPPING"
                } 
                else {
	            $test = $false
                Write-Verbose "$acc - does not have the Lock Memory Privilege - APPLYING"
            }
            
            $test
            
            }

        }

        Script SetManageVolumePrivilegeSQLAGT
        {
            GetScript = {
                $acc = $using:SvcSQLAGT
                $result = Get-UserRightsGrantedToAccount $acc
                $result
            }
    
            SetScript = {
                $acc = $using:SvcSQLAGT
                Grant-UserRight -Account $acc -Right SeManageVolumePrivilege
            
            }
    
            TestScript = {
                $acc = $using:SvcSQLAGT
                $svcacc = Get-UserRightsGrantedToAccount $acc
                if ($svcacc.Right -contains "SeManageVolumePrivilege") {
	            $test = $true
                Write-Verbose "$acc - already has the Lock Memory Privilege - SKIPPING"
                } 
                else {
	            $test = $false
                Write-Verbose "$acc - does not have the Lock Memory Privilege - APPLYING"
            }
            
            $test
            
            }

        }

        Script SQLConfig
        {
            GetScript = {

                #Name of the SQL Server Instance
                $InstanceName = "SCCM"
                #if ($InstanceName -eq "MSSQLSERVER") {$InstanceName = "Default"}
               
                #Path to the Instance
                $InstanceName = "SQLSERVER:\SQL\localhost\$InstanceName" 

            }
    
            SetScript = {
                   
$SQLQuery = @"

/* This shows the advanced options */
EXEC sys.sp_configure N'show advanced options', N'1'  RECONFIGURE WITH OVERRIDE
GO

/* Find the optimal max degree of parallelism setting */
BEGIN
DECLARE @MAXDOP int;
SET @MAXDOP = 
(
	SELECT CASE WHEN cpu_count / hyperthread_ratio > 8 THEN 8 ELSE cpu_count / hyperthread_ratio END AS optimal_maxdop FROM sys.dm_os_sys_info
)
EXEC sys.sp_configure N'max degree of parallelism', @MAXDOP  RECONFIGURE WITH OVERRIDE;
END
GO

/* Change the size and growth parameters of TempDB */
USE [master]
GO
ALTER DATABASE [tempdb] MODIFY FILE ( NAME = N'tempdev', SIZE = 8388608KB , FILEGROWTH = 512000KB )
GO
ALTER DATABASE [tempdb] MODIFY FILE ( NAME = N'templog', SIZE = 2097152KB , FILEGROWTH = 102400KB )
GO

/* Hide the advanced options */
EXEC sys.sp_configure N'show advanced options', N'0'  RECONFIGURE WITH OVERRIDE
GO

"@
                #Name of the SQL Server Instance
                $InstanceName = "SCCM"
                #if ($InstanceName -eq "MSSQLSERVER") {$InstanceName = "Default"}
               
                #Path to the Instance
                $InstanceName = "SQLSERVER:\SQL\$env:COMPUTERNAME\$InstanceName"
                Write-Verbose "$InstanceName"
                #Change to the SQL Server Location
                Import-Module SQLPS
                Set-Location $InstanceName
                #Run the SQL statement
                Invoke-Sqlcmd -ServerInstance (Get-Item .) -Query $SQLQuery
            
            }
    
            TestScript = {
                $TempDB = Get-Item -Path d:\TempDB\tempdb.mdf
                if ($TempDB.Length -eq 8GB) {
                $test = $true
                Write-Verbose "SQL Post-Install Configuration Script already run"
                }
                else {
                $test = $false
                Write-Verbose "Running SQL Post-Install Configuration Script"
                }
                $test
            }

        }

        Script ExtendADSchema
        {
        
            GetScript = {
            
            $ExtSchema = Get-Item -Path "C:\Install\SCCM1511\SMSSETUP\BIN\X64\extadsch.exe"

            if ($ExtSchema = $null) {$result = $false}
            else {$result = $true}

            }

            SetScript = {


            Start-Process "C:\Install\SCCM1511\SMSSETUP\BIN\X64\extadsch.exe" -Verbose -Wait -Verb RunAs
            write-verbose "Running Schema Extension as $(whoami)" -Verbose

            }

            TestScript = {
            
            $test = Test-Path -Path "C:\ExtADSch.log"
            Write-Verbose "AD Schema has been extended - $test" -Verbose
            
            $test
            
            }

            PsDscRunAsCredential = $Credential
        
        }

        Script CreateSMContainer
        {
        
        GetScript = {
            
            $ExtSchema = Get-Item -Path "C:\Install\Create-SMContainer.ps1"

            if ($ExtSchema = $null) {$result = $false}
            else {$result = $true}

            }

        SetScript = {
        


        Start-Process powershell.exe -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File C:\Install\Create-SMContainer.ps1" -Verb RunAs -Wait
        
        
        }

        TestScript = {
            
            $test = Test-Path -Path "C:\SMContainer.log"
            Write-Verbose "System Management Container has been created - $test" -Verbose
            $test
            
            }

        PsDscRunAsCredential = $Credential
        
        }

        WindowsFeature SCCMPreReqs-BITS
        {
            Ensure = "Present"
            Name = "BITS"
        }

        WindowsFeature SCCMPreReqs-RDC
        {
            Ensure = "Present"
            Name = "RDC"
        }

        WindowsFeature SCCMPreReqs-NET-Framework-Features
        {
            Ensure = "Present"
            Name = "NET-Framework-Features"
        }

        WindowsFeature SCCMPreReqs-NET-HTTP-Activation
        {
            Ensure = "Present"
            Name = "NET-HTTP-Activation"
        }

        WindowsFeature SCCMPreReqs-NET-Non-HTTP-Activ
        {
            Ensure = "Present"
            Name = "NET-Non-HTTP-Activ"
        }

        WindowsFeature SCCMPreReqs-Web-Server
        {
            Ensure = "Present"
            Name = "Web-Server"
        }

        WindowsFeature SCCMPreReqs-Web-WMI
        {
            Ensure = "Present"
            Name = "Web-WMI"
        }

        WindowsFeature SCCMPreReqs-Web-Windows-Auth
        {
            Ensure = "Present"
            Name = "Web-Windows-Auth"
        }

        WindowsFeature SCCMPreReqs-Web-Asp-Net
        {
            Ensure = "Present"
            Name = "Web-Asp-Net"
        }

        WindowsFeature SCCMPreReqs-Web-Asp-Net45
        {
            Ensure = "Present"
            Name = "Web-Asp-Net45"
        }

        WindowsFeature SCCMPreReqs-Web-Scripting-Tools
        {
            Ensure = "Present"
            Name = "Web-Scripting-Tools"
        }

        WindowsFeature SCCMPreReqs-UpdateServices-Services
        {
            Ensure = "Present"
            Name = "UpdateServices-Services"
        }

        WindowsFeature SCCMPreReqs-UpdateServices-DB
        {
            Ensure = "Present"
            Name = "UpdateServices-DB"
        }

        WindowsFeature SCCMPreReqs-UpdateServices-UI
        {
            Ensure = "Present"
            Name = "UpdateServices-UI"
        }

        Script ConfigureWSUS
        {
        
        GetScript = {
            
            #Not Required

            }

        SetScript = {
        
            New-Item -Path I: -Name WSUS -ItemType Directory
            Start-Process -FilePath "C:\Program Files\Update Services\Tools\WsusUtil.exe" -ArgumentList "postinstall SQL_INSTANCE_NAME=localhost\SCCM CONTENT_DIR=I:\WSUS" -Wait -Verb RunAs
        
        
        }

        TestScript = {
            
            $test = Test-Path -Path "I:\WSUS"
            Write-Verbose "WSUS has been configured - $test" -Verbose
            $test
            
            }

        PsDscRunAsCredential = $Credential
        
        }

        Script InstallADK
        {
        
        GetScript = {
            
            #Not Required

            }

        SetScript = {
        
           Start-Process -FilePath "C:\Install\SCCM1511\PreReqs\adksetup.exe" -ArgumentList "/features OptionId.DeploymentTools OptionId.WindowsPreinstallationEnvironment OptionId.ImagingAndConfigurationDesigner OptionId.UserStateMigrationTool /ceip off /norestart /quiet" -Wait -Verb RunAs
        
        }

        TestScript = {
            
            $test = Test-Path -Path "C:\Program Files (x86)\Windows Kits\10\Assessment and Deployment Kit"
            $test
            
            }

        PsDscRunAsCredential = $Credential
        
        }

        Script InstallKB3095113
        {
        
        GetScript = {
            
            #Not Required

            }

        SetScript = {
        
           Start-Process -FilePath "C:\Windows\System32\wusa.exe" -ArgumentList "C:\Install\SCCM\PreReqs\Windows8.1-KB3095113-v2-x64.msu /norestart /quiet" -Wait -Verb RunAs
        
        }

        TestScript = {
            
            $test = $false
            $test
            
            }

        PsDscRunAsCredential = $Credential
        
        }

        Script InstallSCCM
        {
        
        GetScript = {
            
            #Not Required

            }

        SetScript = {
        
           Start-Process -FilePath "C:\Install\SCCM1511\SMSSETUP\BIN\X64\setup.exe" -ArgumentList "/script C:\Install\SCCM1511\setup.ini" -Wait -Verb RunAs
        
        }

        TestScript = {
            
            $test = $false
            $test
            
            }

        PsDscRunAsCredential = $Credential
        
        }

    } 

        LocalConfigurationManager 
        {
            ConfigurationMode = 'ApplyOnly'
            RebootNodeIfNeeded = $true

        }
}